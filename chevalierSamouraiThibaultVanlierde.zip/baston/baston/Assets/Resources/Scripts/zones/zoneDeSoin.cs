﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class zoneDeSoin : Zone {

	/* classe correspondantes aux zones qui soignent les personnages qui rentrent dedans
	 * attachés aux plans zonesDeSoins
	 */

	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public override void  appliquerEffet(Bonhomme perso){	//soigne le personnage à l'entrée dans la zone
		perso.soigner();
	}
}
