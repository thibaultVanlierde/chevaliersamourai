﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Zone : MonoBehaviour {

	/* Classe mère des zones à effet sur le sol
	 */

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
		
	public abstract void  appliquerEffet(Bonhomme perso); 	//applique les effets d'une zone
	public virtual void  resetZone(Bonhomme perso){			//retire les effets d'une zone

	}

}
