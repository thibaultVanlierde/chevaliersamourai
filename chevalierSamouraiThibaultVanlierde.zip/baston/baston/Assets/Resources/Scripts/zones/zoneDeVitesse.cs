﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class zoneDeVitesse : Zone {

	/* classe correspondantes aux zones qui augmentent la vitesse des personnages sui sont dans la zone
	 * attachés aux plans zonesDeVitesse
	 */

	// Use this for initialization
	void Start () {
		
	}

	// Update is called once per frame
	void Update () {

	}

	public override void  appliquerEffet(Bonhomme perso){ //effet de la zone : accélère le personnage dans la zone
		perso.accelerer(3);
	}

	public override void resetZone(Bonhomme perso){	//annule les bonus offerts par la zone
		perso.ralentir(3);
	}

}
