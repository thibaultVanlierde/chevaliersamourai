﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class score : MonoBehaviour {

	/* singleton de gestion du score.
	 * Attachée à l'objet scoreText du canvas
	 */

	private static score instance = null; 	//instance des cores
	private int scoreChevalier;			//score des chevaliers
	private int scoreSamourai;			//score des samourais	
	public Text textScore;				//la zone de texte dans laquelle le score est isncrit
	public Text textVictoire;			//zone de texte qui s'affiche lorsque le jeu est gagné par un des camps
	private bool victoire = false;		//passe à true lorsqu'une 
	private bool victoireSamourai = false;	//les samourais on gagnés
	private  bool victoireChevalier = false;//les chevaliers ont gangés
	public int scoreMax = 4;				//points necessaires pour gagner


	public static score getInstance(){	
		return instance;
	}



	// Use this for initialization
	void Start () {
		if (instance == null) {
			instance = this;
		}
		scoreChevalier = 0;
		scoreSamourai = 0;
		updateScore ();	//affiche les scores
	}

	// Update is called once per frame
	void Update () {
		
	}


	public static void augmenterCamp(string camp){	//augmente le score du camp qui gange un point
		if (camp == "Samourai") {
			instance.scoreSamourai++;
		} else {
			instance.scoreChevalier++;
		}
		if (instance.victoire == false) { //si on as pas encore eu de victoire
			if (instance.scoreSamourai == instance.scoreMax) { //on check si le score objectif est atteint pour les samourais
				instance.victoireSamourai = true;
				instance.victoire = true;
				instance.AfficherVictoire ("Samourai");		//afficher la vitoire des chevaliers
			} else if (instance.scoreChevalier == instance.scoreMax) { //on check si le score objectif est atteint pour les chevaliers
				instance.victoireChevalier = true;
				instance.victoire = true;
				instance.AfficherVictoire ("Chevaliers");	//afficher la vitoire des chevaliers

			} else {
				instance.updateScore ();	//on modifie le score avec les nouveaux points
			}
		}
	}

	public void updateScore(){	//met à jour l'affichage du score
		textScore.text = "Score chevalier : " + scoreChevalier.ToString () +" \t\t\t\t\t\t Score Samurai : " + scoreSamourai.ToString () ;
	}

	public void AfficherVictoire (string camp){		//rempli la zone de texte de vitoire avec le camp victorieux
		textVictoire.text = "les " + camp + " ont gagnés !";
		textScore.text = ""; //vide le text du score
	}

	public string getVictoire(){	//renvoie le camp victorieux
		if (victoireChevalier) {
			return "Chevalier";
		} else if (victoireSamourai) {
			return "Samourai";
		} else {
			return "";
		}
	}

	public string getDefaite(){		//renvoie le camp perdant
		if (victoireChevalier) {
			return "Samourai";
		} else if (victoireSamourai) {
			
			return "Chevalier";
		} else {
			return "";
		}
	}

}
