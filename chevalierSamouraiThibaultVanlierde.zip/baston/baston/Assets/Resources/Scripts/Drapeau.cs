﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Drapeau : MonoBehaviour {

	/* Classe gérant les drapeaux
	 * associées aux deux drapeaux
	 */

	Vector3 position;		//position du drapeua
	public GameObject baseCamp;	//position d'origine du drapeau, celle à laquelle il va retourner quand il est laché
	public Bonhomme capturePar; //le personnage possédant le drapeau s'il est capturé
	public enum etatDrapeauEnum { aLaBase, capture};  	//enum pour la machine d'état. à la base : personne ne l'as. capture : quelqu'un le possède
	private etatDrapeauEnum etatDrapeau;		//etat du drapeau

	// Use this for initialization
	void Start () {
		etatDrapeau = etatDrapeauEnum.aLaBase;	
	}
	
	// Update is called once per frame
	void Update () {
		switch (etatDrapeau) {
		case etatDrapeauEnum.capture:
			updatePosDrapeauCapture ();	//bouge le drapeau pour le coller au personnage qui le possède si le drapeau est capturé
			break;
		}

	}

	public void setCapture(Bonhomme par){		//appelé lors de la capture d'un drapeau
		etatDrapeau = etatDrapeauEnum.capture;
		capturePar = par;		//personnage capturant le drapeau : celui auquel le drapeau va être attaché
	}
		
	public etatDrapeauEnum getEtatDrapeau(){	
		return etatDrapeau;
	}

	public void setPosition(Vector3 pos){		//setter de la position
		this.transform.position = position;
	}

	public void resetPosition(){		//repositionne le drapeau à sa base
		position = baseCamp.transform.position;
		this.setPosition (position); 
	}


	public void rendre(){		//change les données du drapeau lorsqu'il doit retourné à la base (soit laché soit ramené à base adverse
		capturePar = null;	
		etatDrapeau = etatDrapeauEnum.aLaBase;
		resetPosition (); 	//le remet à sa position d'origine
		capturePar = null;
	}
		
	public void updatePosDrapeauCapture(){ //update la position du drapeau pour le faire apparaitre à coté du bonhomme le possédant
		position = new Vector3 (capturePar.transform.position.x - 0.78f, capturePar.transform.position.y, capturePar.transform.position.z + 0.55f);
		this.setPosition (position); 
	}
}
