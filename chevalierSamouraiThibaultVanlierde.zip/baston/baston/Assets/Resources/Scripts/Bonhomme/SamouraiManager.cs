﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SamouraiManager : MonoBehaviour {

	/* 		Classe de gestion des samourais. Elle gère leur nombre. Elle les créés et les places lors du lancement du jeu. 
	 * 		Attachée à l'objet 'Samourais' qui contiens tous les samourais
	 */

	public Bonhomme samouraiBase;	// le premier samourai qui existe sur le jeu comme modèle
	public int maxSamourai;			// le nombre de samourais
	private List<Bonhomme> listeSam;//la liste de tous les samourais

	// Use this for initialization
	void Start () {
		listeSam = new List<Bonhomme> ();
		if (samouraiBase != null) { //si on n'as pas de samourai de base, le jeu n'en créé pas
			listeSam.Add (samouraiBase); // on ajoute le premier samourai à la liste
			for (int i = 1; i < maxSamourai; i++) {
				Bonhomme sam = (Instantiate (samouraiBase, samouraiBase.transform.parent));	//on créé moult samourais à partir de celui de base
				sam.init (1, 2, 3, "Samourai", "Chevalier"); //on leurs donnes leurs statistiques (PV, vitesse, temps entre deux attaques, camp, et camp ennemi)
				sam.name = "Samourai" + (i); //rename pour s'y retrouver
				listeSam.Add (sam); 		//ajout à la liste
			}
			placerArmee();		//fonction qui les place tous
		}
	}
	
	// Update is called once per frame
	void Update () {
		foreach (Bonhomme samourai in listeSam) {
			samourai.agir ();	//fait agir les samourais
		}
	}
		
	public void placerArmee(){		///place les samourais en ligne devant leur drapeau.
		//Les samourais se placent comme suit : un au nieau de la base. Un au dessus de la base, un en dessous, un au dessus du premier, un en dessout du second,...

		float x = samouraiBase.baseCamp.transform.position.x;
		float y = 0;
		float z = 0;
		float i = 0; //index qui se reset tous les 11 pour mettre 11 samourais par ligne
		float index = samouraiBase.GetComponent<BoxCollider> ().size.x; //donne un espace entre 2 samourais 
		int hautBas = 0; //un index qui augmente. Permet de savoir si on place au dessus ou en dessous de la base. 
		float tempI = 0;
		foreach (Bonhomme samourai in listeSam) {
			tempI = i;	//
			if (hautBas % 2 != 0) {
				tempI = -i;
				i += index; // on augmente l'aspace par rapport à la base une fois sur deux (quand un au dessus et un en dessous sont placés)
			}
			z = samouraiBase.transform.position.y + tempI;
			samourai.transform.position = new Vector3 (x, y, z); 	//on le place
			hautBas++;
			if (i >= 10) {	//on décale si 11 samourais on étés placés
				i = 0;
				x = x + index;
				hautBas = 0;
			}
		}
	}
}