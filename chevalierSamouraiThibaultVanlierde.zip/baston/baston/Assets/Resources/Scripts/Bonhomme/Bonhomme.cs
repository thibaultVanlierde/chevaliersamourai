﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Bonhomme : MonoBehaviour {

	protected enum Status { Vivant, Mort, Invincible};  //etat de combats
	protected enum StatusDeplacement { versDrapeau, versBase, guerre, attente, respawn, victoire, defaite};  
	//action : déplacement vers le drapeau/la base, en bataille, en atente, mort en attente de respawn, a gagné ou à perdu
	protected Status etat;	
	protected StatusDeplacement action;	
	protected StatusDeplacement actionAvant; //pour revenir à l'action précédente après un combat

	public Drapeau drapeauEnnemi; //les drapeaux
	public Drapeau drapeauAlie;

	public GameObject respawn; 	//position du respawn 
	public GameObject baseCamp;	//position à laquell faut ramener le drapeau

	protected int PV; //pv du personnage.
	protected int startPV;	//pvMaximums d'un bonhomme. 3 pour un chevalier, 1 pour un samourai
	protected int vitesse; //vitesse de déplacement 
	protected string camp; //chevalier ou samourai
	protected string campEnnemi;

	protected bool visible = true; //invisible si on attends le respawn
	protected bool possedeDrapeau = false;	//si un personnage possède le drapeau
	protected int nombreDeces = 0;	//nombre de mort pour incrémenté le respawn à chaque mort

	protected float tpsRespanw = 3f; //temps de respawn 
	protected float timerRespawn;	//utilisé pour calculer le temps de respawn
	protected float tpsInvincible = 0.2f; //tps entre 2 coups. Les personnages ont un temps d'invincibilité entre deux coups
	protected float timerInvincible = 0;
	protected float tpsAttaque; //tps avant de pouvoir attaquer à nouveau
	protected float timerAttaque = 0;
	protected float tpsZone = 3; //tps de pouvoir des zones 
	protected float timerZone = 0;	

	protected bool dansZone;	//s'il est actuellement dans une zone de bonus
	protected Zone zoneActive = null;
	protected bool effetZoneEffectue = false;
	protected bool zoneEnCours = false;

	public Material vivantMat;	//couleur vivant
	public Material invincMat;	//couleur lorsqu'il viens de se prendre un coup

	protected List<Bonhomme> listEnnemis;	//list d'ennemis pour les combats


	// Use this for initialization
	protected virtual void Start () {
		this.listEnnemis = new List<Bonhomme>();
	}

	// Update is called once per frame
	protected virtual void Update () {
		if (this.transform.position.y > 2.5f) {
			this.transform.position = new Vector3(this.transform.position.x,2.5f, this.transform.position.z);	//si se retrouve à sauter trop haut pour n'importe quelle raison, il redéscend
		}
		this.transform.rotation = Quaternion.Euler (0, this.transform.rotation.y, 0); //oblige les personnage à rester droits
	}


	public void init(int _startPv, int _vitesse, int _tpsAttaque, string _camp, string _campEnnemi ){
		//init tous les personnages
		this.startPV = _startPv;
		this.vitesse = _vitesse;
		this.tpsAttaque = _tpsAttaque;
		this.camp = _camp;
		this.campEnnemi = _campEnnemi;
		this.listEnnemis = new List<Bonhomme>();
		this.etat = Status.Vivant;
		this.action = StatusDeplacement.versDrapeau;
		this.PV = startPV;
	}
		
	public void soigner(){
		this.PV = this.startPV;
	}

	public void accelerer(int _vitesse){
		this.vitesse += _vitesse;
	}

	public void ralentir(int _vitesse){
		this.vitesse -= _vitesse;
	}

	protected abstract void deplacementDrapeau(Drapeau drapeau); 
	protected abstract void deplacementBase(GameObject baseCamp);

	protected virtual void ResetPosition(){ //remet le personnage à son respawn
		this.transform.position = respawn.transform.position; 
	}





	public virtual void agir(){	
		//action principale

		this.gererZone (); //on applique les effet de la zone spéciale dans laquelle il est

		switch (action) {
		case StatusDeplacement.versDrapeau:
			if (drapeauEnnemi.getEtatDrapeau () == Drapeau.etatDrapeauEnum.capture) { //on cherche à savoir si le drapeau ennemi a été capturé. 
				//si oui :
				if (possedeDrapeau) { //si le personnage possède le drapeau il va le rendre à sa base
					this.action = StatusDeplacement.versBase;
				} else {//si non, si le drapeau allié est capturé, il se jète sur l'ennemi qui le possède pour le deffendre, sinon attend
					if (drapeauAlie.getEtatDrapeau () == Drapeau.etatDrapeauEnum.capture) {
						this.deplacementDrapeau (drapeauAlie);
					} else {
						this.action = StatusDeplacement.attente;
					}
				}
			} else { //si le drapeau ennemi est pas capturé, va le capturer
				this.deplacementDrapeau (drapeauEnnemi);
			}
			this.checkVictoire ();	//on cherche si un camp à gagner pour mettre fin au jeu
			break;


		case StatusDeplacement.versBase:
			this.deplacementBase (baseCamp);	//vers la base
			this.checkVictoire ();		//on cherche si un camp à gagner pour mettre fin au jeu
			break;


		case StatusDeplacement.guerre:	
			if (this.PV <= 0) {	//si le personnage est mort alors qu'il est en guerre, on le fait tuer
				this.ResetMort ();
			} else {
				this.guerroyer ();	//sinon il va se battre
			}
			this.checkVictoire ();
			break;


		case StatusDeplacement.attente:
			//attend si leur drapeau n'est pas en danger
			if (drapeauEnnemi.getEtatDrapeau () == Drapeau.etatDrapeauEnum.capture) {
				if (drapeauAlie.getEtatDrapeau () == Drapeau.etatDrapeauEnum.capture) {
					this.deplacementDrapeau (drapeauAlie);
				} 
			}else{
				this.action = StatusDeplacement.versDrapeau;
			}

			this.checkVictoire ();
			break;


		case StatusDeplacement.respawn: 
			//attente que le personnage respawn
			float tempTimermort = timerRespawn - Time.time;
			if (tempTimermort < 0) {
				this.etat = Status.Vivant; //le passe de mort à vivant
				foreach (Renderer rend in this.GetComponentsInChildren<Renderer> ()) {
					rend.enabled = true;	//le rends visible
				}
				this.GetComponent<Collider> ().enabled = true; 	//réactive son colider

				this.action = StatusDeplacement.versDrapeau;
			}
			break;


		case StatusDeplacement.victoire: 		
			this.gagner ();
			break;


		case StatusDeplacement.defaite: 
			this.perdre ();
			break;
		}
	}





	protected virtual void capture(){	//lorsqu'un personnage entre en contact avec le drapeau
		if (drapeauEnnemi.getEtatDrapeau() != Drapeau.etatDrapeauEnum.capture) { //si le drapeau n'est pas en possession de quelqu'un
			this.possedeDrapeau = true;
			this.drapeauEnnemi.setCapture (this);	
			this.updatePosDrapeauCapture ();	//met le drapeau au niveau du personnage
			this.action = StatusDeplacement.versBase;
			return;
		}
	}
		
	protected virtual void updatePosDrapeauCapture(){
		this.drapeauEnnemi.updatePosDrapeauCapture (); 
		return;
	}
		
	protected virtual void rendreDrapeau(){	//remet le drapeau à son origine lorsqu'il est ramené à la base
		this.drapeauEnnemi.rendre ();
		this.possedeDrapeau = false;
		this.action = StatusDeplacement.versDrapeau;
	}



	// Batailles
	protected virtual void guerroyer(){
		//action de bataille. les personnage on un temps entre deux attaques (plus court pour les samourais)
		float tempTimerAttaque = 0;
		if (listEnnemis.Count != 0) {	//seulement s'il y a des ennemis autours
			switch (etat) {
			case Status.Vivant:
				//si vivan, il est en état de se battre
				tempTimerAttaque = timerAttaque - Time.time;

				if (tempTimerAttaque <= 0) {	//test pour voir si le temps depuis la dernière attaque est écoulé
					if (listEnnemis [0].etat != Status.Invincible) {	//ne peux pas attaque un ennemi invincible.
						this.blesser (listEnnemis [0]);	//blesse le premier ennemi dela lsite. S'il est mort cela le suprimera de la liste des ennemis
						if (listEnnemis.Count == 0) {
							this.FinGuerroyer (); 	
						}
						this.timerAttaque = Time.time + tpsAttaque;
					}
				}
				break;
			

			case Status.Invincible:
				//peut se battre si invicible
				foreach (Renderer rend in this.GetComponentsInChildren<Renderer> ()) {
					rend.material = this.invincMat;	//couleur pour montrer qu'il est invincible
				}
				 
				float tempTimer = this.timerInvincible - Time.time;	
				if(tempTimer < 0 ){	//si le timer d'invincibilité est fini
					foreach (Renderer rend in this.GetComponentsInChildren<Renderer> ()) {
						rend.material = vivantMat;	//remet les couleur d'état vivant
					}
					this.timerInvincible = 0;
					if (PV <= 0) {	//le met mort si à 0 pv ou moins
						this.etat = Status.Mort;
					} else { //sinon il peut toujours se battre
						this.etat = Status.Vivant;
					}
				}
				//attaque comme à l'état vivant
				tempTimerAttaque = this.timerAttaque - Time.time;
				if (tempTimerAttaque <= 0) {
					if (this.listEnnemis [0].etat != Status.Invincible) {
						this.blesser (listEnnemis [0]);
						if (this.listEnnemis.Count == 0) {
							this.FinGuerroyer (); 
						}
						this.timerAttaque = Time.time + this.tpsAttaque;
					}
				}
				break;


			case Status.Mort:
				//ne peut pas vraiment se battre, il respawn 
				this.ResetMort ();
				break;
			}


		} else {
			this.FinGuerroyer ();	//si la liste d'ennemis est vide on arrète la bataille 
		}
	}

	protected virtual void ResetMort(){//remet le bonhomme à son origine, pase en respawn et active le timer de respawn
		if (possedeDrapeau) {
			this.drapeauEnnemi.rendre ();	//remet le drapeau à son origine 
			this.possedeDrapeau = false;
		}
		this.ResetPosition ();
		this.PV = startPV;	//remet les pv à 0
		this.listEnnemis.Clear ();
		this.action = StatusDeplacement.respawn; 
		this.timerRespawn = this.tpsRespanw + this.nombreDeces + Time.time;
		this.nombreDeces++;	//pour augmenter le temps de respawn à chaque mort
		foreach (Renderer rend in this.GetComponentsInChildren<Renderer> ()) {
			rend.enabled = false;	//le rends ivisible
		}
		this.GetComponent<Collider> ().enabled = false; 

	}

	protected virtual void blesser(Bonhomme mechant){//enlève un pv à l'ennemi. et le retire de la liste des ennemis si tué. lui active l'etat invincible
		mechant.PV--;
		mechant.etat = Status.Invincible;
		mechant.timerInvincible = Time.time + tpsInvincible;
		if (mechant.PV <= 0) {
			this.listEnnemis.RemoveAt (0);
		}
	}

	protected virtual void FinGuerroyer (){	//le personnage recommence à faire l'action qu'il faisait avant
		if (this.etat != Status.Mort) {
			this.etat = Status.Vivant;
			foreach (Renderer rend in this.GetComponentsInChildren<Renderer> ()) {
				rend.material = this.vivantMat;
			}
			this.action = actionAvant;
		} else {
			this.ResetMort ();
		}
		this.listEnnemis.Clear ();
	}





	protected virtual void checkVictoire(){	//regarde si un camp à gagné. pour arreter le jeu
		if (score.getInstance () != null) {
			if (score.getInstance ().getVictoire () == camp) {
				this.action = StatusDeplacement.victoire;
			}
			if (score.getInstance ().getDefaite () == camp) {
				this.action = StatusDeplacement.defaite;
			}
		}
	}

	protected void gagner(){	//fait le ver les bras et sauter sur place les personnages de l'équi gagnante. Inutile mais rigolo
		if (this.transform.position.y < 0.05) {
			this.GetComponent<Rigidbody> ().AddForce (new Vector3(0,25,0));
		}
		this.GetComponentInChildren<Transform>().Find("brasDroit").rotation = Quaternion.Euler (-30f, 0, 0);
		this.GetComponentInChildren<Transform>().Find("brasGauche").rotation =  Quaternion.Euler (-30f, 0, 0);
	}

	protected void perdre(){	//fait baisser les bras et la tête de l'équi perdante pour leur donner un air triste. Inutile mais rigolo
		this.GetComponentInChildren<Transform>().Find("brasDroit").rotation = Quaternion.Euler (30f, 0, 0);
		this.GetComponentInChildren<Transform>().Find("brasGauche").rotation =  Quaternion.Euler (30f, 0, 0);
		this.GetComponentInChildren<Transform>().Find("tete").rotation =  Quaternion.Euler (30f, 0, 0);
	}





	protected virtual void gererZone(){	//applique les effet d'une zone une fois à l'entrée de la zone. 
		if (this.zoneActive != null) {	//si personnage est dans une zone
			if(this.effetZoneEffectue == false){	//si l'effet de la zone n'as pas déja été activé
				this.effetZoneEffectue = true;
				this.zoneActive.appliquerEffet (this);
				this.zoneActive = null;
			}
		}
	}
		



	protected virtual void OnTriggerEnter(Collider objet){
		if(objet.gameObject.CompareTag("Drapeau"+campEnnemi)){	//capture le drapeau
			this.capture();
		}
		if(objet.gameObject.CompareTag(campEnnemi)){	//en cas de bataille
			
			if(!listEnnemis.Contains(objet.gameObject.GetComponent<Bonhomme>())){	//si le personnage rencontré n'est pas déja dans la liste des ennemis avec qui le personnage se bat
				//le personnage ne peut pas se battre avec un personnage en respawn, ou qui n'est pas encore en respawn mais va l'être (phase d'invincibilité après le dernier coup. ne les fait pas se battre en cas de victoire/défaite
				if (objet.gameObject.GetComponent<Bonhomme> ().PV > 0 && objet.gameObject.GetComponent<Bonhomme>().action != StatusDeplacement.respawn && this.action !=  StatusDeplacement.respawn && this.action != StatusDeplacement.defaite && this.action != StatusDeplacement.victoire) {					

					this.listEnnemis.Add (objet.gameObject.GetComponent<Bonhomme> ()); //ajoute l'ennemi à la liste des ennemis

					if (action != StatusDeplacement.guerre) {
						this.actionAvant = action;	//note l'action avant la guerre s'il n'était pas en train de se battre
					}
					this.action = StatusDeplacement.guerre;

				}
			}
		}
		if(objet.gameObject.CompareTag("base"+camp)){	//on augment le score si on rends le drapeau
			if(this.drapeauEnnemi.getEtatDrapeau() == Drapeau.etatDrapeauEnum.capture && this.possedeDrapeau == true){
				score.augmenterCamp(camp);
				this.rendreDrapeau ();
			}
		}

		if(objet.gameObject.CompareTag("zone")){	//applique l'effet d'une zone
			if (this.dansZone == false) {
				this.zoneEnCours = false;
				this.dansZone = true;
				this.zoneActive = objet.gameObject.GetComponent<Zone> ();
			}
		}
	}


	void OnTriggerExit(Collider objet)
	{
		if(objet.gameObject.CompareTag("zone")){ 		//lorsqu'on quite une zone, annule son effet si son effet doit être annulé
			if (this.zoneEnCours == false) {	//si le personnage n'as pas encore vu l'efet annulé
				this.dansZone = false;			//n'est lus dans une zone
				this.effetZoneEffectue = false;
				objet.gameObject.GetComponent<Zone> ().resetZone (this);
				this.zoneEnCours = true;
			}
		}
	}
		
}
