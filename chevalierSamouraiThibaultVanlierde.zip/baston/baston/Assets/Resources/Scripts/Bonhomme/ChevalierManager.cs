﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChevalierManager : MonoBehaviour {

	/* 		Classe de gestion des chevaliers. Elle gère leur nombre. Elle les créés et les places lors du lancement du jeu. 
	 * 		Attachée à l'objet 'Chevaliers' qui contiens tous les Chevalier
	 */

	public Bonhomme chevalierBase;	// le premier chevalier qui existe sur le jeu comme modèle
	public int maxChevalier;		// le nombre de chevaliers
	private List<Bonhomme> listeChev;//la liste de tous les chevaliers

	// Use this for initialization
	void Start () {
		listeChev = new List<Bonhomme> ();
		if (chevalierBase != null) {//si on n'as pas de chevalier de base, le jeu n'en créé pas
			listeChev.Add (chevalierBase); // on ajoute le premier chevalier à la liste
			for (int i = 1; i < maxChevalier; i++) {
				Bonhomme chev = (Instantiate (chevalierBase, chevalierBase.transform.parent)); //on créé moult chevaliers à partir de celui de base
				chev.init (3, 1, 4, "Chevalier", "Samourai");	//on leurs donnes leurs statistiques (PV, vitesse, temps entre deux attaques, camp, et camp ennemi)
				chev.name = "Chevalier" + (i);	//rename pour s'y retrouver
				listeChev.Add(chev);			//ajout à la liste
			}
			placerArmee ();		//fonction qui les place tous
		}
	}

	// Update is called once per frame
	void Update () {
		foreach (Bonhomme chevalier in listeChev) {
			chevalier.agir ();	//fait agir les chevaliers
		}
	}

	public void placerArmee(){///place les chevaliers en ligne devant leur drapeau.
		//Les chevaliers se placent comme suit : un au nieau de la base. Un au dessus de la base, un en dessous, un au dessus du premier, un en dessout du second,...

		float x = chevalierBase.baseCamp.transform.position.x;
		float y = 0;
		float z = 0;
		float i = 0;	//index qui se reset tous les 11 pour mettre 11 chevaliers par ligne
		float index = chevalierBase.GetComponent<BoxCollider> ().size.x;//donne un espace entre 2 chevaliers 
		int hautBas = 0; //un index qui augmente. Permet de savoir si on place au dessus ou en dessous de la base. 
		float tempI = 0;
		foreach (Bonhomme chevalier in listeChev) {
			tempI = i;
			if (hautBas % 2 != 0) {
				tempI = -i;
				i += index;// on augmente l'aspace par rapport à la base une fois sur deux (quand un au dessus et un en dessous sont placés)
			}
			z = chevalierBase.transform.position.y + tempI;
			chevalier.transform.position = new Vector3 (x, y, z); //on le place
			hautBas++;
			if (i >= 10) {	//on décale si 11 chevaliers on étés placés
				i = 0;
				x = x - index;
				hautBas = 0;
			}
		}
	}
}