﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AssemblyCSharp
{
	/* classe de gestion des chevaliers
	 * attachée aux objets chevalier
	 */

	public class chevalier : Bonhomme
	{
		// Use this for initialization
		protected override void Start () {
			init (3, 1, 5, "Chevalier", "Samourai");	//initialise les chevaliers à leur création. leurs donnes leurs statistiques (PV, vitesse, temps entre deux attaques, camp, et camp ennemi)
			base.Start ();	
		}

		// Update is called once per frame
		protected override void Update () {
			base.Update ();
		}
			

		protected override void deplacementDrapeau(Drapeau drapeau){		
			//actions pour se déplacer vers le drapeau. Les chevaliers marchent en rang et se déplacent uniquement en ligne droite. Ils se déplacent d'abbord de droite à gauche puis en hauteur
			if (this.transform.position.y < 0.2) {
				this.GetComponent<Rigidbody> ().AddForce (new Vector3(0,30,0)); //fait bondir un peu les chevaliers lorsqu'ils se déplacent. C'est innutile mais les chvaliers ont l'air moins rigides
			}

			Vector3 positionDrapeau = drapeau.transform.position;
			Vector3 position = this.transform.position; 
			//on trouve les deux positions et on déplace les personnages en ligne droite. On les tourne vers la dirrection qu'ils prennent en marchant
			if (position.x <= positionDrapeau.x -0.5 && position.x <= positionDrapeau.x +0.5) {
				this.transform.Translate (new Vector3(0.1f, 0, 0)*vitesse, Space.World);
				this.transform.rotation = Quaternion.Euler(0, 90, 0);
				return;
			} else if(position.x >= positionDrapeau.x -0.5 && position.x >= positionDrapeau.x +0.5){
				this.transform.Translate (new Vector3(-0.1f, 0, 0)*vitesse,Space.World);
				this.transform.rotation = Quaternion.Euler(0, 270, 0);
				return;
			}else if(position.z <= positionDrapeau.z-0.5  && position.z <= positionDrapeau.z +0.5){
				this.transform.Translate (new Vector3(0, 0, 0.1f)*vitesse, Space.World);
				this.transform.rotation = Quaternion.Euler(0, 0, 0);
				return;
			}else if(position.z >= positionDrapeau.z-0.5  && position.z >= positionDrapeau.z +0.5){
				this.transform.Translate (new Vector3(0, 0, -0.1f)*vitesse,Space.World);
				this.transform.rotation = Quaternion.Euler(0, 180, 0);
				return;
			}
		}


		protected override void deplacementBase(GameObject baseCamp){
			//action pour se déplacer vers la base. Les chevaliers marchent en rang et se déplacent uniquement en ligne droite. Ils se déplacent d'abbord en hauteur puis de droite à gauche
			if (this.transform.position.y < 0.2) {
				this.GetComponent<Rigidbody> ().AddForce (new Vector3(0,30,0));
			}
			Vector3 positionBase = baseCamp.transform.position;
			Vector3 position = this.transform.position;

			if(position.z <= positionBase.z-0.5  && position.z <= positionBase.z +0.5){
				this.transform.Translate (new Vector3(0, 0, 0.1f)*vitesse, Space.World);
				this.transform.rotation = Quaternion.Euler(0, 0, 0);
				return;
			}else if(position.z >= positionBase.z-0.5  && position.z >= positionBase.z +0.5){
				this.transform.Translate (new Vector3(0, 0, -0.1f)*vitesse,Space.World);
				transform.rotation = Quaternion.Euler(0, 180, 0);
				return;
			}else if (position.x <= positionBase.x -0.5 && position.x <= positionBase.x +0.5) {
				this.transform.Translate (new Vector3(0.1f, 0, 0)*vitesse, Space.World);
				transform.rotation = Quaternion.Euler(0, 90, 0);
				return;
			} else if(position.x >= positionBase.x -0.5 && position.x >= positionBase.x +0.5){
				this.transform.Translate (new Vector3(-0.1f, 0, 0)*vitesse,Space.World);
				transform.rotation = Quaternion.Euler(0, 270, 0);
				return;
			} 
		}
	}
}

