﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace AssemblyCSharp
{
	public class Samourai : Bonhomme {

		/* classe de gestion des samourais
	 * attachée aux objets samourai
	 */

		// Use this for initialization
		protected override void Start () {
			init (1, 2, 3, "Samourai", "Chevalier");	//initialise les samourai à leur création. leurs donnes leurs statistiques (PV, vitesse, temps entre deux attaques, camp, et camp ennemi)
			base.Start ();
		}
		
		// Update is called once per frame
		protected override void Update () {
			base.Update ();
		}
			
		protected override void deplacementDrapeau(Drapeau drapeau){
			//actions pour se déplacer vers le drapeau. Les samourais marchent en groupe et se déplacent dirrectement vers le drapeau
			if (this.transform.position.y < 0.2) {
				this.GetComponent<Rigidbody> ().AddForce (new Vector3(0,30,0));  //fait bondir un peu les samourai lorsqu'ils se déplacent. C'est innutile mais les chvaliers ont l'air moins rigides
			}

			Vector3 dirrection = drapeau.transform.position - this.transform.position;
			//récupère dirrectement le vecteur de dirrection et l'angle par rapport au repère de base
			float angle = Vector3.Angle(new Vector3(0,0,1), dirrection);
			this.transform.Translate (0.1f*dirrection.normalized*vitesse, Space.World);
			if (drapeau.transform.position.x > this.transform.position.x) {	
				this.transform.rotation = Quaternion.Euler (0, angle, 0);
			} else {
				this.transform.rotation = Quaternion.Euler (0, -angle, 0);
			}//il existe sgnedAngle dans version plus récentes : ma version n'est pas à jour
		}


		protected override void deplacementBase(GameObject baseCamp){
			//actions pour se déplacer vers le drapeau. Les samourais marchent en groupe et se déplacent dirrectement vers la base
			if (this.transform.position.y < 0.2) {
				this.GetComponent<Rigidbody> ().AddForce (new Vector3(0,30,0));
			}
			Vector3 dirrection = baseCamp.transform.position - this.transform.position;
			float angle = Vector3.Angle(new Vector3(0,0,1), dirrection);
			this.transform.Translate (0.1f*dirrection.normalized*vitesse, Space.World);
			if (baseCamp.transform.position.x > this.transform.position.x) {
				this.transform.rotation = Quaternion.Euler (0, angle, 0);
			} else {
				this.transform.rotation = Quaternion.Euler (0, -angle, 0);
			}//il existe sgnedAngle dans version plus récentes : à mettre à jour à l'occasion
		}
	}
}
